from django.shortcuts import render

def home(request):
    return render(request, 'home.html')

def estudiantes(request):
    data = [
        {"carne": "090-21-09543", "nombre": "Amilcar Calel", "carrera": "Ing. Sistemas"},
        {"carne": "2026-27151", "nombre": "Denis López", "carrera": "Ing. Sistemas"},
    ]
    return render(request, 'estudiantes.html', {"estudiantes": data})

def administradores(request):
    data = [
        {"usuario": "admin", "nombre": "Iván de León", "email": "ivan@example.com"},
        
    ]
    return render(request, 'administradores.html', {"administradores": data})

def acerca(request):
    return render(request, 'acerca.html')
