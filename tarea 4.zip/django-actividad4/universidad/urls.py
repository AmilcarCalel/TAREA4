from django.contrib import admin
from django.urls import path
from sitio import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('estudiantes/', views.estudiantes, name='estudiantes'),
    path('administradores/', views.administradores, name='administradores'),
    path('acerca/', views.acerca, name='acerca'),
]
